﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace paletta
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void sliRGB_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            byte red, green, blue;
            red = Convert.ToByte(sliPiros.Value);
            green = Convert.ToByte(sliZold.Value);
            blue = Convert.ToByte(sliKek.Value);
            rctTeglalap.Fill = new SolidColorBrush(Color.FromRgb(red, green, blue));

            piros_szam.Content = red;
            zold_szam.Content = green;
            kek_szam.Content = blue;
            
        }

        private void btnRogzit_Click(object sender, RoutedEventArgs e)
        {
            string x = $"{Convert.ToByte()}"
            lbSzinek.Items.Add(piros_szam.Content + " ; " + zold_szam.Content + " ; " + kek_szam.Content);
            if (lbSzinek.Items.Contains(lbSzinek.Items))
            { 
            }
        }

        private void btnTorol_Click(object sender, RoutedEventArgs e)
        {
            if (lbSzinek.SelectedIndex == -1)
            {
                MessageBox.Show("kuka");
            }
            else
            {
                lbSzinek.Items.RemoveAt(lbSzinek.SelectedIndex);
            }
        }

        private void btnUrit_Click(object sender, RoutedEventArgs e)
        {
            lbSzinek.Items.Clear(); 
        }
    }
}
